package com.example.firebaseapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import android.widget.*;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    EditText textid , textpass ;
    Button btnsave ;
    DatabaseReference reff;
    Member member ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
    //Toast.makeText(MainActivity .this,"FireBase connection Success",Toast.LENGTH_LONG).show();
        textid = (EditText)findViewById(R.id.TextID);
        textpass =(EditText)findViewById(R.id.TextPass);
        btnsave = (Button)findViewById(R.id.BtSave);
        member = new Member();
        reff = FirebaseDatabase.getInstance().getReference().child("Member");
        btnsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                member.setID(textid.getText().toString().trim());
                member.setPASS(textpass.getText().toString().trim());

                reff.push().setValue(member);

                Toast.makeText(MainActivity .this,"FireBase connection Success",Toast.LENGTH_LONG).show();

            }
        });
}
}