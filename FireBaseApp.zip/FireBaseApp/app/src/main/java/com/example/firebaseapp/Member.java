package com.example.firebaseapp;

public class Member {
    private String  ID;
    private String PASS;

    public Member()
    {
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getPASS() {
        return PASS;
    }

    public void setPASS(String PASS) {
        this.PASS = PASS;
    }
}
